import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import HerosList from './components/HerosList'

class App extends Component {

  
  render() {
    return (
      <HerosList />
    );
  }
}

export default App;
